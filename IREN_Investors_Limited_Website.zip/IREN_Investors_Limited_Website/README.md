# IREN Investors Limited Website

This package contains the supplied IREN Investors Limited HTML interface as a static website.

## Developer access
- `index.html` — complete website source
- `CNAME` — intended custom domain: `www.ireninvestorslimited.com`

## Publish with GitHub Pages
1. Create a GitHub repository you control.
2. Upload `index.html` and `CNAME`.
3. In Settings → Pages, enable GitHub Pages and select the publishing source.
4. Add `www.ireninvestorslimited.com` as the custom domain.
5. At your domain registrar, create a CNAME record for `www` pointing to your GitHub Pages hostname.

The domain must be registered by you separately; this package does not transfer domain ownership or hosting credentials.

## Important
The supplied interface should be treated as a website/demo until real backend authentication, database, payment processing, legal disclosures, security controls, and financial/regulatory compliance are implemented.
